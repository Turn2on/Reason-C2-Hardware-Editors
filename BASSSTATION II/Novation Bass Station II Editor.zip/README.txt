Novation Bass Station II Editor for Reason
Based on the MIDI OUT DEVICE (stck Reason device). For using it, select actual Midi output device into the DEVICES mode)

BASS STATION II Combinator 2.0 editor created by Turn2on Software and can be used free.

DOWNLOAD THIS COMBINATOR EDITOR AND OTHERS AT OUR SITE:
https://turn2on.com/combinators/


*** 
All product names, trademarks and registered trademarks,  brands are the property of their respective owners. All companies, products and brands, manufacturers names and model designations used are for identification purposes only and are not intended to infringe on the copyrights of their respective owners. Use of these names, trademarks, brands, artists names does not imply any affiliation or co-operation with or endorsement by them with Turn2on. 
*** 

Combinator files can’t be edited (backdrops changed to new one) and used for the Commercial use (sale new patches based on this Combinator patch)

***

TRY OUR RACKEXTENSIONS 

TURN2ON SOFTWARE:
https://turn2on.com/